# OUTCOME OF TESTS FOR PROJECT shopping1_s

As of Mar 25 2021 18:25:15

| ID | NAME | RESULT | COMMENTS |
| :----- |:------ | :---: | :---: |
| 1::1 | _01_Basics.DateTime_Constructors | PASSED | OK |
| 1::2 | _01_Basics.DateTime_Constructors | PASSED | OK |
| 2::1 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::2 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::3 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::4 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::5 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::6 | _01_Basics.DateTime_getters | PASSED | OK |
| 3::1 | _01_Basics.DateTime_set | PASSED | OK |
| 4::1 | _01_Basics.Event_ConstructorBase | PASSED | OK |
| 4::2 | _01_Basics.Event_ConstructorBase | PASSED | OK |
| 5::1 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::2 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::3 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::4 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::5 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::6 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::7 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 6::1 | **_01_Basics.Integration_ECommerce5** | **FAILED** | **Activity found: SUNDAY(0) MONDAY(0) [-TUESDAY(5)-] {+TUESDAY(0)+} WEDNESDAY(0) THURSDAY(0) [-FRIDAY(0)-] {+FRIDAY(5)+} SATURDAY(0) Records read: 5 Valid [-records:-] {+events readed:+} 5 Max activity: 5 Day of Max activity: [-TUESDAY-] {+FRIDAY+}** |
| 7::1 | **_01_Basics.Integration_EMPTY** | **FAILED** | **Activity found: SUNDAY(0) MONDAY(0) TUESDAY(0) WEDNESDAY(0) THURSDAY(0) FRIDAY(0) SATURDAY(0) Records read: 0 Valid [-records:-] {+events readed:+} 0 Max activity: 0 Day of Max activity: SUNDAY** |
| 8::1 | **_01_Basics.Integration_ECommerce49** | **FAILED** | **Activity found: SUNDAY(0) MONDAY(0) [-TUESDAY(49)-] {+TUESDAY(1)+} WEDNESDAY(0) THURSDAY(0) [-FRIDAY(0)-] {+FRIDAY(48)+} SATURDAY(0) Records read: [-49-] {+48+} Valid [-records:-] {+events readed:+} 49 Max activity: [-49-] {+48+} Day of Max activity: [-TUESDAY-] {+FRIDAY+}** |
| 9::1 | **_01_Basics.Integration_ECommerce_2019_Q4_200** | **FAILED** | **Activity found: [-SUNDAY(25) MONDAY(36) TUESDAY(32) WEDNESDAY(32) THURSDAY(25) FRIDAY(32) SATURDAY(18)-] {+SUNDAY(2) MONDAY(0) TUESDAY(0) WEDNESDAY(0) THURSDAY(1) FRIDAY(197) SATURDAY(0)+} Records read: [-200-] {+198+} Valid [-records:-] {+events readed:+} 200 Max activity: [-36-] {+197+} Day of Max activity: [-MONDAY-] {+FRIDAY+}** |
| 10::1 | **_01_Basics.Integration_ECommerce_all_all_200** | **FAILED** | **Activity found: [-SUNDAY(30) MONDAY(25) TUESDAY(29) WEDNESDAY(37) THURSDAY(33) FRIDAY(24) SATURDAY(22)-] {+SUNDAY(0) MONDAY(0) TUESDAY(1) WEDNESDAY(0) THURSDAY(0) FRIDAY(199) SATURDAY(0)+} Records read: [-200-] {+199+} Valid [-records:-] {+events readed:+} 200 Max activity: [-37-] {+199+} Day of Max activity: [-WEDNESDAY-] {+FRIDAY+}** |
| 11::1 | _02_Intermediate.DateTime_isBefore | PASSED | OK |
| 11::2 | _02_Intermediate.DateTime_isBefore | PASSED | OK |
| 11::3 | _02_Intermediate.DateTime_isBefore | PASSED | OK |
| 12::1 | _02_Intermediate.DateTime_weekDay | PASSED | OK |
| 12::2 | _02_Intermediate.DateTime_weekDay | PASSED | OK |
| 12::3 | _02_Intermediate.DateTime_weekDay | PASSED | OK |
| 13::1 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::2 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::3 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::4 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::5 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::6 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::7 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::8 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::9 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::10 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 14::1 | _03_Advanced.Event_setType_Bad_Values | PASSED | OK |
| 14::2 | _03_Advanced.Event_setType_Bad_Values | PASSED | OK |
| 15::1 | _03_Advanced.Event_Others_Bad_Values | PASSED | OK |
| 15::2 | _03_Advanced.Event_Others_Bad_Values | PASSED | OK |
| 15::3 | _03_Advanced.Event_Others_Bad_Values | PASSED | OK |
